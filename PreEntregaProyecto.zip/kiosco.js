let nombreCliente = document.getElementById("name");
let telefCliente = document.getElementById("telef");
let edadCliente = document.getElementById("edad");
let direccionCliente = document.getElementById("direcc");
const registrarse = document.getElementById("registrar");
let mayorEdad;
let contador = 0;
const usuarios = [];
const productos = [];

function Usuario (nombreApellido, telefono, edad, direccion){
    this.nombre= nombreApellido;
    this.telefono= telefono;
    this.edad= Number(edad);
    this.direccion= direccion;
    if (this.edad > 18) {
        mayorEdad = confirm("¿Confirmás que sos mayor de edad?");
        if(mayorEdad){
            alert("Al confirmar que sos mayor de edad tenés acceso a todos los productos.");
        } else {
            alert("Hay productos exclusivos para mayores de edad los cuales no podrás acceder.")
        }
    } else {
        alert("Hay productos exclusivos para mayores de edad los cuales no podrás acceder.")
    }
}

function Producto (producto, descripcion, precio,categoria,stock){
    this.producto = producto;
    this.descripcion = descripcion;
    this.precio = Number(precio);
    this.categoria = categoria;
    this.stock = Number(stock);
}

function nuevoCliente(usuarios) {
    return usuarios.push(
		new Usuario(
			nombreCliente.value,
			telefCliente.value,
			edadCliente.value,
			direccionCliente.value
		)
	);
}

registrarse.addEventListener("click", () => {
    nuevoCliente(usuarios);
    console.table(usuarios);
});